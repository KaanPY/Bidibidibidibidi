﻿namespace arduinoTest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cmbPortlar = new System.Windows.Forms.ComboBox();
            this.btnAcKapat = new System.Windows.Forms.Button();
            this.lblBaglantiDurumu = new System.Windows.Forms.Label();
            this.kaan = new System.IO.Ports.SerialPort(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnLedAcKapat = new System.Windows.Forms.Button();
            this.lblLedDurum = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmbPortlar
            // 
            this.cmbPortlar.FormattingEnabled = true;
            this.cmbPortlar.Location = new System.Drawing.Point(28, 19);
            this.cmbPortlar.Name = "cmbPortlar";
            this.cmbPortlar.Size = new System.Drawing.Size(146, 21);
            this.cmbPortlar.TabIndex = 0;
            // 
            // btnAcKapat
            // 
            this.btnAcKapat.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnAcKapat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAcKapat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnAcKapat.Location = new System.Drawing.Point(28, 46);
            this.btnAcKapat.Name = "btnAcKapat";
            this.btnAcKapat.Size = new System.Drawing.Size(146, 23);
            this.btnAcKapat.TabIndex = 1;
            this.btnAcKapat.Text = "Bağlantıyı Aç/Kapat";
            this.btnAcKapat.UseVisualStyleBackColor = true;
            this.btnAcKapat.Click += new System.EventHandler(this.btnAcKapat_Click);
            // 
            // lblBaglantiDurumu
            // 
            this.lblBaglantiDurumu.ForeColor = System.Drawing.Color.White;
            this.lblBaglantiDurumu.Location = new System.Drawing.Point(28, 72);
            this.lblBaglantiDurumu.Name = "lblBaglantiDurumu";
            this.lblBaglantiDurumu.Size = new System.Drawing.Size(146, 23);
            this.lblBaglantiDurumu.TabIndex = 2;
            this.lblBaglantiDurumu.Text = "Bağlantı Durumu";
            this.lblBaglantiDurumu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbPortlar);
            this.groupBox1.Controls.Add(this.lblBaglantiDurumu);
            this.groupBox1.Controls.Add(this.btnAcKapat);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bağlantı Aç/Kapat";
            // 
            // btnLedAcKapat
            // 
            this.btnLedAcKapat.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnLedAcKapat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLedAcKapat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnLedAcKapat.Location = new System.Drawing.Point(30, 29);
            this.btnLedAcKapat.Name = "btnLedAcKapat";
            this.btnLedAcKapat.Size = new System.Drawing.Size(119, 23);
            this.btnLedAcKapat.TabIndex = 4;
            this.btnLedAcKapat.Text = "Led Aç/Kapat";
            this.btnLedAcKapat.UseVisualStyleBackColor = true;
            this.btnLedAcKapat.Click += new System.EventHandler(this.btnLedAcKapat_Click);
            // 
            // lblLedDurum
            // 
            this.lblLedDurum.Location = new System.Drawing.Point(30, 56);
            this.lblLedDurum.Name = "lblLedDurum";
            this.lblLedDurum.Size = new System.Drawing.Size(119, 23);
            this.lblLedDurum.TabIndex = 6;
            this.lblLedDurum.Text = "Led Durumu: Kapalı";
            this.lblLedDurum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblLedDurum);
            this.groupBox2.Controls.Add(this.btnLedAcKapat);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(218, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(178, 100);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Led Aç/Kapat";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.ClientSize = new System.Drawing.Size(406, 124);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Arduino test";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbPortlar;
        private System.Windows.Forms.Button btnAcKapat;
        private System.Windows.Forms.Label lblBaglantiDurumu;
        private System.IO.Ports.SerialPort kaan;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnLedAcKapat;
        private System.Windows.Forms.Label lblLedDurum;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}

