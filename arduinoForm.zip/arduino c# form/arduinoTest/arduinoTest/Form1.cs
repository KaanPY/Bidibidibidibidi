﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
namespace arduinoTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] port = SerialPort.GetPortNames();
            foreach (var kaan in port)
                cmbPortlar.Items.Add(kaan);
            if (port.Length > 0)
            {
                cmbPortlar.SelectedIndex = 0;
            }
            

        }

        private void btnAcKapat_Click(object sender, EventArgs e)
        {
            if (kaan.IsOpen)
            {
                kaan.Close();
                lblBaglantiDurumu.Text = "Bağlantı kapalı";
                lblBaglantiDurumu.ForeColor = Color.Red;
            }
            else
            {
                kaan.PortName = cmbPortlar.Text;
                kaan.Open();
                lblBaglantiDurumu.Text = string.Format("{0} port aktif", cmbPortlar.Text);
                lblBaglantiDurumu.ForeColor = Color.Green;
            }
        }

        bool acikMi = true;
        private void btnLedAcKapat_Click(object sender, EventArgs e)
        {
            if (kaan.IsOpen && acikMi)
            {
                kaan.Write("1");
                lblLedDurum.Text = "Led Durumu: Açık";
                lblLedDurum.ForeColor = Color.Green;
                acikMi = false;
            }
            else if (kaan.IsOpen && acikMi == false)
            {
                kaan.Write("0");
                lblLedDurum.Text = "Led Durumu: Kapalı";
                lblLedDurum.ForeColor = Color.Red;
                acikMi = true;
            }
            else
                MessageBox.Show("Port Durumu Kapalı! Portu açınız.");     
        }
    }
}
